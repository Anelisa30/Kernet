var n1 = document.getElementById('num');
var n2 = document.getElementById('num1');
var res = document.getElementById('res');

document.getElementById('add').addEventListener('', function(){
  res.value=parseInt(n1.value)+parseInt(n2.value);
});
